<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => 'themes://woo/woo.yaml',
    'modified' => 1502852948,
    'data' => [
        'enabled' => true,
        'color' => 'blue',
        'dropdown' => [
            'enabled' => false
        ]
    ]
];
