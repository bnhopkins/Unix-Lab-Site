<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/Users/brookehopkins/Downloads/grav-skeleton-woo-site/user/plugins/problems/problems.yaml',
    'modified' => 1502852946,
    'data' => [
        'enabled' => true,
        'built_in_css' => true
    ]
];
