<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/Users/brookehopkins/Downloads/grav-skeleton-woo-site/user/config/plugins/simple_form.yaml',
    'modified' => 1502852946,
    'data' => [
        'enabled' => true,
        'token' => '',
        'template_file' => 'simple_form',
        'fields' => NULL,
        'messages' => [
            'success' => 'Your message has been sent.'
        ]
    ]
];
