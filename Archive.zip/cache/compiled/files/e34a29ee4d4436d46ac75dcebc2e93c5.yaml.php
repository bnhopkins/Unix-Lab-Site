<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/Users/brookehopkins/Downloads/grav-skeleton-woo-site/user/config/security.yaml',
    'modified' => 1504378900,
    'data' => [
        'salt' => 'AzbEM0f6xRPnYX'
    ]
];
