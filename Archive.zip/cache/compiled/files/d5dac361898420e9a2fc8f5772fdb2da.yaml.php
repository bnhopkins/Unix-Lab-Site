<?php
return [
    '@class' => 'Grav\\Common\\File\\CompiledYamlFile',
    'filename' => '/Users/brookehopkins/Downloads/grav-skeleton-woo-site/system/blueprints/config/media.yaml',
    'modified' => 1502852946,
    'data' => [
        'title' => 'PLUGIN_ADMIN.MEDIA',
        'form' => [
            'validation' => 'loose',
            'fields' => NULL
        ]
    ]
];
