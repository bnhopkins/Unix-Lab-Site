
---
title: // UNIX LAB
showcase_image: hero-image.png
---

Student-run computer science space at NYU Abu Dhabi.
