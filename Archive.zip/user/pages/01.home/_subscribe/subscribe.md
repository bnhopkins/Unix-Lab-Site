<div class="row section-head">
<div class="twelve columns" markdown="1">
  #Stay up to date on events.
  Receive our newsletter about events and updates, and unsubscribe any time.
  <!-- Adding your own MailChimp powered email sign-up is easy.
  Grab the super slim code from your MailChimp account and drop the code here. Lastly, remove the link and style tags
  that comes with the embedded code and your good to go. All styling is within our stylesheet. -->
</div>
</div>

<div class="row">

 <div class="twelve columns">

   <!-- Begin MailChimp Signup Form -->

   <div id="mc_embed_signup">
     <form action="//space.us16.list-manage.com/subscribe/post?u=9feab4a4165506089c00fc754&amp;id=44e37cd77c" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>

      <input type="email" value="" name="EMAIL" class="email" id="mce-EMAIL" placeholder="email address" required>
      <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
      <div style="position: absolute; left: -5000px;"><input type="text" name="b_9feab4a4165506089c00fc754_44e37cd77c" value=""></div>
      <div class="clear"><input type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="button"></div>

    </form>
  </div>

  <p><small>We never share your information or use it to spam you.</small></p>

</div>

</div>
