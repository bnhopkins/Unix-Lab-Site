---
title: Projects
visible: false
rows:
  - title: Events
    description: Technology centered events to encourage and promote exploration of technology. Hackathons. Tech talks. Speakers. Hack nights.
    description_position: right
    image: feature-image-1.png
    name: design
  - title: Student-led projects.
    description: A space with the resources and community for students to create projects that solve real world problems at NYUAD and beyond.
    description_position: left
    image: feature-image-2.png
    name: responsive
  - title: One on one tutoring.
    description: Open [hours](hours) for students to come with homework, lab or extra-curricular project questions. 
    description_position: right
    image: feature-image-3.png
    name: cross-browser
  - title: Community.
    description: A 24 space for students to come together to study and work, allowing for greater collaboration and support.
    description_position: left
    image: feature-image-4.png
    name: video
---
