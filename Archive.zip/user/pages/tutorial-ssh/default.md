---
title: SSH to Lab Machines
---

#SSHing into Machines
The lab has 16 machines, and all of these may be SSHed into from the local network.

####Unix Machines (Mac and RedHat)


####Windows Machines
