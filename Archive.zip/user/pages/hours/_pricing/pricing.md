---
columns:
  - title: Starter
    price1: Brooke
    price2: per month
    image: sample-image.jpg
    features:
      - name: 1GB Storage
      - name: 5GB Bandwidth
      - name: 2 Domains
      - name: 3 Databases
      - name: 1 FTP Account
      - name: 25 Email Accounts
    buttons:
      - text: Sign Up
        url: "#"
  - title: Standard
    price1: Brooke
    price2: per month
    icon: thumbs-up
    features:
      - name: 3GB Storage
      - name: 10GB Bandwidth
      - name: 3 Domains
      - name: 5 Databases
      - name: 3 FTP Account
      - name: 30 Email Accounts
    buttons:
      - text: Sign Up
        url: "#"
  - title: Premium
    price1: Brooke
    price2: per month
    icon: star
    features:
      - name: Monday
      - name: 2-5pm
      - name: Wednesday
      - name: 2-5pm
    buttons:
      - text: Sign Up
        url: "#"
  - price1: Brooke
    price2: per month
    icon: trophy
    features:
      - name: 30GB Storage
      - name: Unlimited Bandwidth
      - name: 10 Domains
      - name: 15 Databases
      - name: 10 FTP Account
      - name: 50 Email Accounts
    buttons:
      - text: Sign Up
        url: "#"               
---
#Tutor hours.
Lab monitors are available for any computer science related questions throughout the year.
