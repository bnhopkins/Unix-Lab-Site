<?php
namespace Grav\Theme;

use Grav\Common\Theme;

class Woo extends Theme
{

}
