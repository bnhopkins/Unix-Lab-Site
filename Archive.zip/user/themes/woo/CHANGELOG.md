# v1.2.0
## 07/14/2016

1. [](#improved)
    * Remove unneeded streams from Theme YAML
    * Delete unused composer.json
1. [](#bugfix)
    * Fix setting the page language in the html tag
    
# v1.1.1
## 09/04/2015

1. [](#bugfix)
    * menu linking bug

# v1.1.0
## 08/25/2015

1. [](#improved)
    * Added blueprints for Grav Admin plugin

# v1.0.0
## 05/09/2015

1. [](#new)
    * ChangeLog started...
